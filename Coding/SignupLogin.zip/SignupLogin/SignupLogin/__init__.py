import pymysql

# 使用MySQL数据库
pymysql.install_as_MySQLdb()
